﻿using System;

namespace ForLoop
{
    public class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //Logic for the t loops through [1..100]
            for (int i = 0; i <= 100; i++)
            {
                if ((i % 3 == 0) && (i % 5 == 0))
                {
                    Console.WriteLine(i + " fizzbuzz");
                }
                else if (i%3 == 0)
                {
                    Console.WriteLine(i + " fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine(i+ " buzz");
                }
            }

            
            var sourceString = Console.ReadLine();
            //Calling the Reverse String Method
            string reverserd = Reverse(sourceString);

            Console.WriteLine(reverserd);
        }
        public static string Reverse(string sourceString)
        {
            string revsersedString = "";
            //Logic for Reverse the String
            for (int i = sourceString.Length - 1; i >= 0; i--)
            {
                revsersedString += sourceString[i];
            }
            return revsersedString;
        }
    }

  
}
