﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InMarCodeTestProject.Models
{
    public class OfferService
    {
        private List<Product> Inventory { get; set; }
    }
}
