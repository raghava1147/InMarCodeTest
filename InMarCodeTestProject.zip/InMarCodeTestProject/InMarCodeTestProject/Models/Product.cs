﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InMarCodeTestProject.Models
{
    public class Product
    {
        public string ProductName { get; set; }
        public decimal Price { get; set; }

        public string Description { get; set; }

        public Product()
        {
            ProductName = "Apple";
            Price = 99000;
            Description = "Branded mobile company";
        }
    }
}
