﻿using InMarCodeTestProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace InMarCodeTestProject.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //Logic for the t loops through [1..100]
            for (int i=0;i<=100;i++)
            {
                if(i%3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if(i%5 == 0)
                {
                    Console.WriteLine("buzz");
                }
                else if((i%3 == 0) &&(i%5 ==0))
                {
                    Console.WriteLine("fizzbuzz");
                }
            }

            //Logic for reverse string
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
